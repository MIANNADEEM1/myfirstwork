<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateForm2ASTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('form2_a_s', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->timestamps();
            $table->string('ProjectName');
            $table->string('ProjectDescription');
            $table->string('ProjectCategory');
            $table->text('temail')->nullable();
            $table->text('tname')->nullable();
            $table->string('file');
            $table->string('link');
            $table->string('REI');
            $table->string('business');
            $table->string('oname')->nullable();
            $table->string('oname1')->nullable();
            $table->string('oemail')->nullable();
            $table->string('oemail1')->nullable();
            $table->string('ocontact')->nullable();
            $table->string('ocontact1')->nullable();
            $table->string('members'); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('form2_a_s');
    }
}
