<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Form4 extends Model
{
    protected $fillable = [
         'interaction', 'festival__materials', 'Previous',
         'Previous_info','DropDown','Surname','First_name','Contact_info'
        ,'Email','condition1','condition2','Other','Explain',
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
}
