<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Http\Request;
use Illuminate\Routing\Route;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\User;
use App\Form2A;
use App\Form3;
use App\Form4;
use Illuminate\Support\Facades\Mail;
use App\Mail\FeedbackMail;
use App\Mail\Form2Mail;
use Illuminate\Support\Facades\Storage;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

public function reg(){
    return view('feedback');
}
public function btncheck(){
    return view('buttoncheck');
}

//////////////// Starts from here form1
public function registered(Request $request ){
    $temail = [];
    $temail[] = [
        'tname' => $temail,
        
    ];
    $user = new User;
    $user->FirstName= $request->input('FirstName');
    $user->password= $request->input('password');
    $user->email= $request->input('email');
    $user->LastName= $request->input('LastName');
    $user->info= $request->input('info');
    $user->Location= $request->input('Location');
    $user->Gender= $request->input('Gender');
    $user->DOB= $request->input('DOB');
    $user->Nationality= $request->input('Nationality');
    $user->Phone= $request->input('Phone');
    $user->members= $request->input('members');
    
    $user->temail= json_encode($request->input('temail'));
    $user->tname= json_encode($request->input('tname'));
    $user1 = User::where('email', $request->email)->first();
    if ($user1) {
            return redirect('reg')->with('status', 'Email Already exists Please Use another Email');
    }
  
    request()->validate([

        'Phone'=>'required|max:13|min:13',
        'email'=>'required',
        'password'=>'required|min:8',
        
       
       
    ]);
    if($user->members=='team'){
    request()->validate([

        'tname'=>'required|array',
        'temail'=>'required|array',
        
        
       
       
    ]);
    }
    $user->save();
    if($user->save()){
    $comment = 'Hi, This test feedback.';
    // dd(json_decode($user->temail));
    if($user->members=='team'){
    foreach(json_decode($user->temail) as $email) {
      
        Mail::to($email)->send(new FeedbackMail($comment));
    }
}
else{
    Mail::to($user->email)->send(new FeedbackMail($comment));
   
    }
}

     echo " Success message: Thank you for creating an account with ADEK Innovator2020. Emails have been sent to you and all your team members and we will now help you fill in the rest of your project details. ";
}

/////////////////////////Form 1 ends here
public function reg2(){
    return view('form2');
}
public function reg3(){
    return view('form3');
}
public function reg4(){
    return view('form4');
}

public function registered2(Request $request ){
   
    $form = new Form2A;
    $form->ProjectName= $request->input('ProjectName');
    $form->ProjectDescription= $request->input('ProjectDescription');
    $form->ProjectCategory= $request->input('ProjectCategory');
    $form->file=json_encode($request->input('file'));
    $form->link= $request->input('link');
    $form->REI= $request->input('REI');
    $form->business= $request->input('business');   //////
    $form->oname= $request->input('oname');  
    $form->oname1= $request->input('oname1');  
    $form->oemail= $request->input('oemail');  
    $form->oemail1= $request->input('oemail1');
    $form->ocontact= $request->input('ocontact');  
    $form->ocontact1= $request->input('ocontact1');  
    $form->temail= json_encode($request->input('temail'));
    $form->tname= json_encode($request->input('tname'));
    $form->members= $request->input('members');
    request()->validate([
      
        'ProjectName'=>'required',
        'ProjectDescription'=>'required|max:100',
       'ProjectCategory'=>'required',  
       'link'=>'required|url', 
        'REI'=>'required',
        'business'=>'required',
       
       
    ]);
    if($form->members=='team'){
        request()->validate([
    
            'tname'=>'required|array',
            'temail'=>'required|array',
            
            
           
           
        ]);
        }
    if($form->REI=='yes'){
        request()->validate([
      
         'oemail'=>'required',
         'oname'=>'required',
        'ocontact'=>'required',  
        
        
     ]);
        }
        if($form->business=='yes'){
     request()->validate([
          
       
        'ocontact1'=>'required',
        'oemail1'=>'required',
        
        'oname1'=>'required',
        
        
     ]);}
     

    
     $form->save();
     request()->validate([
       
        'file'=>'required',
        'file.*' => 'required|image|mimes:jpeg,jpg,gif,png,svg|max:2048'
        ]);
   if ($files = $request->file('file')) {
       $destinationPath = 'public/image/'; // upload path
       $file = date('YmdHis') . "." . $files->getClientOriginalExtension();
       $files->move($destinationPath, $file);
    }
   
   
    $form->save();
    if($form->save())
    {
        $comment = 'Hi, This test feedback.';
    
        if($form->members=='team'){
        foreach(json_decode($form->temail) as $email) {
          
            Mail::to($email)->send(new Form2Mail($comment));
        }
    }
  
    }
  
     echo "  Success message: Thank you for creating an account with ADEK Innovator2020. Emails have been sent to you and all your team members and we will now help you fill in the rest of your project details.";
}
public function registered3(Request $request ){
 
    $user = new Form3;
    $user->Teachername= $request->input('Teachername');
    $user->Schoolname= $request->input('Schoolname');
    $user->Pemail= $request->input('Pemail');
    $user->Pname= $request->input('Pname');
    $user->Pphone= $request->input('Pphone');
    $user->Gender= $request->input('Gender');
    $user->Schoollocation= $request->input('Schoollocation');
    $user->temail= $request->input('temail');
    $user->Tphone= $request->input('Tphone');
    $user->age= $request->input('age');
    request()->validate([
    
         
        'Gender'=>'required',
         'Schoollocation'=>'required',
         'age'=>'required',
        
       
    ]);
    if($user->age=='Below'){
        request()->validate([
    
         
            'Pemail'=>'required',
            'Pphone'=>'required',
                
            'temail'=>'required',
            
           
        ]);
        
        }
  
 
    $user->save();

     echo " Registration Successful";
}
public function registered4(Request $request){
   
  
    $user = new Form2A;
    $user->interaction= $request->input('interaction');
  
   
    $user->festival__materials= $request->input('festival__materials');
    $user->Previous= $request->input('Previous');
  
    $user->Previous_info= $request->input('Previous_info');
    $user->DropDown= $request->input('DropDown');
    $user->Surname= $request->input('Surname');
    $user->First_name= $request->input('First_name');
    $user->Contact_info= $request->input('Contact_info');
    $user->Email= $request->input('Email');
    $user->Explain= $request->input('Explain');
    $user->Other= $request->input('Other');
    $user->condition1= $request->input('condition1'); 
    $user->condition2= $request->input('condition2');
    $user1 = Form4::where('Email', $request->Email)->first();
    if ($user1) {
            return redirect('reg4')->with('status', 'Email Already exists Please Use another Email');
    }
     request()->validate([

     
        'interaction'=>'required',
        'Previous'=>'required',
        'DropDown'=>'required',
       
        
       
    ]);
    if($user->Previous=='yes'){
    request()->validate([

        'Previous_info'=>'required',
    ]);
}
if($user->interaction=='yes'){
    request()->validate([

        'Explain'=>'required',
    ]);
}
if($user->DropDown=='Other'){
    request()->validate([

        'Other'=>'required',
    ]);
}
    $user->save();

     echo " Successfull";
}








}
