<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Form4</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  
  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="savy.min.js"></script>
  
  <script>
    $(document).ready(function(){
      $("#yess").click(function(){
        $("#cf").html('<div id="rm"> <label for="explain">Explain:</label> <textarea class="auto-save form-control" rows="4"  name="Explain" id="ab" required></textarea></div>');
      });
    
     
    });

    $(document).ready(function(){
  $("#noo").click(function(){
    $("#rm").remove();
  });
});

$(document).ready(function(){
      $("#py").click(function(){
        $("#cf2").html('<div id="rm1"> <label for="explain">Enter Previous Info:</label> <textarea class="auto-save form-control" rows="3"  name="Previous_info" id="bb" placeholder="Enter Previous_info" required></textarea></div>');
      });
    
     
    });
    $(document).ready(function(){
  $("#Pn").click(function(){
    $("#rm1").remove();
  });
});
$(document).ready(function(){
      $("#other").click(function(){
        $("#cf3").html('<div id="rm3"> <label for="hear">Other:</label> <textarea class="auto-save form-control" rows="2"  name="Other" id="sp" placeholder="Please specify" required></textarea></div>');
      });
    
     
    });
    //////////////////////////////
    $(document).ready(function(){
  $("#B").click(function(){
    $("#rm3").remove();
  });
});
$(document).ready(function(){
  $("#C").click(function(){
    $("#rm3").remove();
  });
});
$(document).ready(function(){
  $("#D").click(function(){
    $("#rm3").remove();
  });
});
$(document).ready(function(){
  $("#E").click(function(){
    $("#rm3").remove();
  });
});
$(document).ready(function(){
  $("#F").click(function(){
    $("#rm3").remove();
  });
});
$(document).ready(function(){
  $("#G").click(function(){
    $("#rm3").remove();
  });
});
$(document).ready(function(){
  $("#H").click(function(){
    $("#rm3").remove();
  });
});
$(document).ready(function(){
  $("#I").click(function(){
    $("#rm3").remove();
  });
});
$(document).ready(function(){
  $("#J").click(function(){
    $("#rm3").remove();
  });
});
    </script>

</head>
<body>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<div class="container">
<form method="POST" action="registered4">
    <h2> Form 4 </h2>
    <label> Attendies to INNOVATOR 2020 be able to interact with your exibit ?</label>
    <div class="form-check">
      <label class="form-check-label" for="radio2"> 
        <div>
        <input type="radio" class="auto-save form-check-input" id="noo" name="interaction" value="no" required>No </label>
        </div>
    </div>
   
    <div class="form-check" >
      <label class="form-check-label" for="radio2">
        <input type="radio" class="auto-save form-check-input" id="yess" name="interaction" value="yes" required>Yes
      </label>
    </div>
    <div class="container-fluid" id="cf">

    </div>
    <br>
  <p> <label> What Materials will you bring to festiavl to display along side your exibhit </label> </p>
   
    <div class="form-group">
     
        <input type="text" class="form-control" id="festival__materials" name="festival__materials" placeholder="Enter here" required>
      </div>
      <label><p>Have you entered your invention/project (or any part of it) into any other public competitions/events/exhibitions previously?</P></label>
<br>
<div class="form-check">
    <label class="form-check-label" for="radio1">
      <input type="radio" class="form-check-input" id="Pn" name="Previous" value="No">No, this is the first time my project has been on public display

    </label>
  </div>
  <div class="form-check">
    <label class="form-check-label" for="radio2">
      <input type="radio" class="form-check-input" id="py" name="Previous" value="yes">Yes, my project has been displayed at the below competition/event/exhibition:
    </label>
  </div>
  <div class="container-fluid" id="cf2">
   
    
  </div>
<br>
    <div class="form-group">
        <label for="DropDown">How did you hear about INNOVATOR 2020? Dropdown with the following options?:</label>
        <select class="form-control"  name="DropDown">
        <option id="A">Select option</option>
          <option id="B">Radio Facebook</option>
          <option id="C">TV</option>
          <option id="D">Magazine</option>
          <option id="E">Website</option>
          <option id="F">Twitter</option>
          <option id="G">YouTube</option>
          <option id="H">Friend</option>
          <option id="I">University / Institute / School Work</option>
          <option id="J">INNOVATOR 2019 Ambassador</option>
          <option id="other">Other</option>
        </select>
      </div>
      <div class="container-fluid" id="cf3">

      </div>
      <label><p>Do you know of any people or organisations’ that would be suitable to be a part of this project?</P></label>
        <div class="form-group">
     <label>Surname: </label>
            <input type="text" class="form-control" id="Surname" name="Surname" placeholder="Enter Surname" required>
          </div>
          <div class="form-group">
            <label>First Name: </label>
 <input type="text" class="form-control" id="First_name" name="First_name" placeholder="Enter First_name" required>
</div>
 <div class="form-group">
    <label>Contact No: </label>
  <input type="tel" class="auto-save form-control bfh-phone" data-format="+92 (ddd) ddd-dddd" pattern="[0-9]{4}-[0-9]{3}-[0-9]{4}"  id="Contact_no" name="Contact_info" placeholder="Enter Contact_No" required>
 </div>
<div class="form-group">
<label>Email Adress:: </label>
  <input type="email" class="form-control" id="Email" name="Email" placeholder="Enter Email" required>
  </div>
  <div class="form-check">
 <input type="checkbox" class="form-check-input" name="condition1" id="condition1" required>
 <label class="form-check-label" for="condition1">By ticking this box, you confirm you will be available to exhibit your invention on all 10 days (Jan 30 - Feb 8) of INNOVATOR 2020 in Abu Dhabi </label>
 </div>
<div class="form-check">
 <input type="checkbox" class="form-check-input" name="condition2" id="condition2" required>
 <label class="form-check-label" for="condition2">By selecting this box, you are verifying that you have read and will adhere to INNOVATOR 2020 Guidelines</label>
</div>

        <br>
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <button type="submit">Create</button>
  </form>
</div>
 
<?php /**PATH C:\xampp\htdocs\work\resources\views/form4.blade.php ENDPATH**/ ?>