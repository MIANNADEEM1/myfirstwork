<!DOCTYPE html>
<head>
  <title> Form2</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  
  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="savy.min.js"></script>
  <script>
    $(function() {  
   $('.auto-save').savy('load');
  });
  $(function() {  
   $( "#hello2" ).click(function() {
      $('.auto-save').savy('destroy');
    });
  });
        </script>
<script>
  $(document).ready(function(){
    $("#t").click(function(){
      $("#cf").html('<div id="rm"> <label for="name">Team member Name:</label><input type="text" class="form-control" name="tname[]" id="nm1"  required><label for="email">Team member Email:</label><input type="text" class="form-control" name="temail[]" id="em1" required><input id="btnAdd1" type="button" value=" + ADD more members"> &nbsp<input id="other" type="button" value=" -"><label>&nbsp &nbsp &nbsp Each team Member wiil be sent an email to join the personal details</label></div>');
    });
  
   
  });
  $(document).ready(function(){
  $(document).on('click','#rm #other', function () {
    $("#rm1").remove();
  });
});
  </script>
   <script>
    $(document).ready(function () {
      $(document).on('click','#rm #btnAdd1', function () {
       
          var newListItem = $('<div id="rm1"> <label for="name">Team member Name:</label><input type="text" class="form-control" name="tname[]" required><label for="email">Team member Email:</label><input type="text" class="form-control" name="temail[]" required></div>').on('click', function () {
             
          });
 
          $('#cf').append(newListItem);
      });
  });
 </script> 

<script>
$(document).ready(function(){
  $("#ck").click(function(){
    $("#cf11").html('<div id="rmm"> <label for="usr">Name Of Orginaization:</label><input type="text" class="auto-save form-control" name="oname" required><label for="email">Email Of Orginaization:</label><input type="text" class="auto-save form-control" name="oemail" required><label for="contact">Contact Of Orginaization:Phone: Format: 0334-044-6789</label><input type="text"  data-format="+92 (ddd) ddd-dddd" pattern="[0-9]{4}-[0-9]{3}-[0-9]{4}" id="tel" class="auto-save form-control" name="ocontact" required></div>');
  });

 
});

$(document).ready(function(){
  $("#ck1").click(function(){
    $("#cf22").html('<div id="rmm2"> <label for="usr">Name Of Orginaization:</label><input type="text" class="auto-save form-control" name="oname1" required><label for="email">Email Of Orginaization:</label><input type="text" class="auto-save form-control" name="oemail1" required><label for="email">Contact Of Orginaization:Phone: Format: 0334-044-6789</label><input type="text"  data-format="+92 (ddd) ddd-dddd" pattern="[0-9]{4}-[0-9]{3}-[0-9]{4}" id="tel" class="auto-save form-control" name="ocontact1" required></div>');
  });

 
});
$(document).ready(function(){
  $("#ck3").click(function(){
    $("#rmm").remove();
  });

 
});
$(document).ready(function(){
  $("#ck4").click(function(){
    $("#rmm2").remove();
  });

 
});
</script>
</head>
<body>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="container">
  <h2>Registration Form</h2>
  <form action="registered2" method="post"  >
  <div class="form-group">
      <label for="ProjectName">ProjectName:</label>
      <div>
      <input type="text" class="auto-save form-control"  placeholder="Enter Project name" name="ProjectName"
      class="auto-save form-control" id="1" required>
      </div>
    </div>
  <div class="form-group"  >
      <label for="ProjectDescription">ProjectDescription:</label>
      <div>
      <input type="text" class="auto-save form-control" id="6m" placeholder="Enter ProjectDescription" name="ProjectDescription" required>
      </div>
    </div>
    <div class="form-group">
  <label for="ProjectCategory">ProjectCategory:</label>
  <select class="auto-save form-control"  name="ProjectCategory" id="noid">
  <option>ProjectCategory</option>
    <option>Art&Design</option>
    <option>Automotive,Mechanice,Digital Fabrication</option>
    <option>Robotics,Electronics</option>
   
  </select>
</div>
<div class="form-group">
<div>
<input  type="file" class="auto-save form-control" name="file[]" id="img" multiple>
      
          
</div>

  
    
     
            </div>
       
      <label for="videlink">VideoLink:</label>
      <input type="text" class=" auto-save form-control"  placeholder="Enter video link" name="link" required>
      <br>
    <label>Does your project represent an educational Institution</label>
      <div class="form-check" id="one">
   
      <label><input  type="radio" class="auto-save " id="ck" value="yes" name="REI" required>Yes</label>
      </div>
<div class="container-fluid" id="cf11">

</div>
  
   
    <div class="form-check">
      <label><input type="radio" class="auto-save " value="no"  name="REI" id="ck3" required>No</label>
    </div>
    <label> Does you represent BUSINESS </label>
    <div class="form-check"id="two">
    
      <label><input type="radio" class="auto-save " value="yes" name="business" id="ck1" required>Yes</label>
    </div>
    <div class="container-fluid" id="cf22">

    </div>
    <div class="form-check">
      <label><input type="radio" class="auto-save " value="no"  name="business"id="ck4" required>No</label>
    </div>
    <br>
    <label> Are you an individual Innovator or Team of Innovators</label>
    <div class="form-check">
      <label class="form-check-label" for="radio2"> 
        <div>
        <input type="radio" class=" form-check-input" id="i" name="members" value="individual" required>Individual: </label>
        </div>
    </div>
   
    <div class="form-check" id="">
      <label class="form-check-label" for="radio2">
        <input type="radio" class="auto-save " class=" form-check-input" id="t" name="members" value="team" required>Team
      </label>
    </div>
    <div class="container-fluid" id="cf">

    </div>
    <div class="container-fluid" id="cf1">

    </div>



    <br>
   
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <button type="submit">Create</button>
   
    
  </form>
 
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\work\resources\views/form2.blade.php ENDPATH**/ ?>